"""Causal/noncausal direct-output and default-dispatch qualification only."""
import argparse
import hashlib
import importlib.metadata as md
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import traceback
from types import SimpleNamespace

sys.path.insert(0,os.environ.get('COMFY_ROOT',str(Path(__file__).resolve().parents[1]/'ComfyUI')))
import torch
import comfy_kitchen as ck
from patches import kitchen_attention as attention


def error(actual, expected):
    a, b = actual.double(), expected.double(); delta=a-b
    return dict(relative_l2=float(delta.norm()/b.norm().clamp_min(1e-30)),
        max_abs=float(delta.abs().max()),finite=bool(torch.isfinite(a).all() and torch.isfinite(b).all()))


def oracle(q,k,v,mask=None,scale=None):
    q,k,v=[x.float() for x in (q,k,v)]
    k,v=[x.repeat_interleave(q.shape[1]//x.shape[1],1) for x in (k,v)]
    rows=[];scale=q.shape[-1]**-.5 if scale is None else scale
    for start in range(0,q.shape[2],128):
        scores=(q[:,:,start:start+128]@k.transpose(-1,-2))*scale
        if mask is not None:
            m=mask.expand(q.shape[0],q.shape[1],q.shape[2],k.shape[2])[:,:,start:start+128]
            scores=scores.masked_fill(~m,float('-inf')) if m.dtype==torch.bool else scores+m.float()
        rows.append(scores.softmax(-1)@v)
    return torch.cat(rows,2)


def inputs(n,nk,d,h,hk,rank,seed,dtype=torch.float32,b=1):
    gen=torch.Generator(device=rank).manual_seed(seed)
    return tuple(torch.randn(b,heads,length,d,device=rank,generator=gen).to(dtype)
                 for heads,length in ((h,n),(hk,nk),(hk,nk)))


def mask_for(n,nk,kind,device,dtype=torch.float32):
    if kind=='none':return None
    allowed=torch.arange(nk,device=device)[None,:]<=torch.arange(n,device=device)[:,None]
    if kind=='causal_bool':return allowed[None,None]
    if kind=='key':
        mask=torch.zeros(1,1,1,nk,device=device,dtype=dtype)
        mask[...,nk//2:]=float('-inf');mask[...,3:7]=.125
        return mask
    mask=torch.zeros((1,1,n,nk),device=device,dtype=dtype).masked_fill(~allowed,torch.finfo(dtype).min/4)
    if kind=='padding_bias':mask[...,17]=torch.finfo(dtype).min/4;mask[:,:,31:,:1]+=.125
    elif kind!='causal_additive':raise ValueError(kind)
    return mask


def measure(functions,repeats=7,iterations=8):
    result={name:dict(wall_ms=[],cuda_ms=[]) for name in functions}
    for fn in functions.values():
        for _ in range(3):fn()
    torch.cuda.synchronize()
    for repeat in range(repeats):
        order=list(functions) if repeat%2==0 else list(functions)[::-1]
        for name in order:
            start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
            torch.cuda.synchronize();begin=time.perf_counter();start.record()
            for _ in range(iterations):functions[name]()
            end.record();end.synchronize()
            result[name]['wall_ms'].append((time.perf_counter()-begin)*1000/iterations)
            result[name]['cuda_ms'].append(start.elapsed_time(end)/iterations)
    for name,row in result.items():
        row.update(median_wall_ms=statistics.median(row['wall_ms']),median_cuda_ms=statistics.median(row['cuda_ms']))
    return result


def save(path,state):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(path)


def worker(rank,output,local=False):
    torch.cuda.set_device(rank);torch.backends.cuda.matmul.allow_tf32=False
    torch.set_float32_matmul_precision('highest')
    capability=list(torch.cuda.get_device_capability(rank))
    if not local:assert capability==[7,5] and 'T4' in torch.cuda.get_device_name(rank)
    state=dict(status='running',rank=rank,gpu=torch.cuda.get_device_name(rank),capability=capability,
        uuid=str(torch.cuda.get_device_properties(rank).uuid),precision=[],controls=[],timing=[],unsupported=[],
        scope='Synthetic attention/default dispatch only; no full H3 or trained-model quality')
    started=time.monotonic()
    try:
        arch='120' if local else '75'
        attention.validate_library(os.environ[attention.LIBRARY_ENV],arch)
        with torch.inference_mode():
            # FP32/FP64 oracle sanity uses a bounded CPU calculation.
            q,k,v=inputs(17,23,64,4,2,rank,108)
            r32=oracle(q,k,v)
            kh,vh=[x.double().cpu().repeat_interleave(2,1) for x in (k,v)]
            r64=((q.double().cpu()@kh.transpose(-1,-2))*64**-.5).softmax(-1)@vh
            torch.testing.assert_close(r32.cpu().double(),r64,rtol=2e-5,atol=2e-6)
            state['controls'].append(dict(kind='oracle_vs_cpu_fp64',**error(r32.cpu(),r64)))
            cases=[(65,65,64,4,2),(129,129,128,32,4),(353,353,128,32,4),
                   (513,513,128,32,4),(1025,1025,128,32,4),
                   (128,1153,128,4,2),(65,1153,64,4,2),
                   (65,131,32,4,2),(65,131,80,4,2),(31,65,192,4,2),(31,65,79,4,2)]
            if local:cases=[cases[i] for i in (0,2,5,6,7,8,9,10)]
            for n,nk,d,h,hk in cases:
                for seed in ((821,) if local or n!=353 else (821,1709)):
                    q,k,v=inputs(n,nk,d,h,hk,rank,seed)
                    for kind in ('none','causal_bool','causal_additive','key','padding_bias'):
                        if kind=='padding_bias' and min(n,nk)<32:continue
                        if time.monotonic()-started>300:raise TimeoutError('Attention qualification deadline')
                        mask=mask_for(n,nk,kind,rank)
                        try:old=ck.int8_attention(q,k,v,attn_mask=mask)
                        except RuntimeError as exc:
                            if d<=128:raise
                            try:attention.int8_attention(q,k,v,attn_mask=mask)
                            except RuntimeError:
                                state['unsupported'].append(dict(n=n,nk=nk,d=d,mask=kind,
                                    pinned_error=str(exc),candidate_also_rejected=True));continue
                            raise AssertionError('Candidate accepted a pinned unsupported configuration')
                        direct=attention.int8_attention(q,k,v,attn_mask=mask)
                        assert direct.dtype==torch.float32 and direct.shape==q.shape
                        assert direct.is_contiguous() and direct.stride()==old.stride()
                        assert torch.equal(old,old.bfloat16().float()),'Pinned FP32 baseline did not use BF16 store'
                        assert torch.equal(direct.bfloat16().float(),old),'Direct-store rounded result changed pinned arithmetic'
                        expected=oracle(q,k,v,mask)
                        state['precision'].append(dict(n=n,nk=nk,d=d,h=h,hk=hk,seed=seed,mask=kind,
                            old_vs_fp32=error(old,expected),direct_vs_fp32=error(direct,expected),
                            baseline_bf16_lattice=True,rounded_byte_equal=True,
                            changed_fraction=float((direct!=old).float().mean())))
                    save(output,state)
            # Noncontiguous Q/K/V, B2, broadcast masks and custom signed scale.
            for scale in (.25,0.,-.125):
                q,k,v=inputs(65,131,128,4,2,rank,903,b=2)
                q,k,v=[x.transpose(1,2).contiguous().transpose(1,2) for x in (q,k,v)]
                mask=mask_for(65,131,'causal_additive',rank)
                old=ck.int8_attention(q,k,v,scale=scale,attn_mask=mask)
                new=attention.int8_attention(q,k,v,scale=scale,attn_mask=mask)
                assert torch.equal(new.bfloat16().float(),old)
                state['controls'].append(dict(kind='noncontiguous_B2_signed_scale',scale=scale,rounded_byte_equal=True,
                    direct_vs_fp32=error(new,oracle(q,k,v,mask,scale))))
            for dtype in (torch.float16,torch.bfloat16):
                for kind in ('none','causal_additive','key'):
                    q,k,v=inputs(353,353,128,32,4,rank,821,dtype)
                    mask=mask_for(353,353,kind,rank,dtype)
                    old=ck.int8_attention(q,k,v,attn_mask=mask)
                    new=attention.int8_attention(q,k,v,attn_mask=mask)
                    assert torch.equal(new,old) and new.dtype==dtype
                    state['controls'].append(dict(kind='low_precision_pinned_path',dtype=str(dtype),mask=kind,byte_equal=True))
            from patches.h3_operator_policy import H3OperatorPolicy,te_attention,dit_attention
            block=SimpleNamespace(operator_policy=H3OperatorPolicy())
            q,k,v=inputs(353,353,128,32,4,rank,821)
            mask=mask_for(353,353,'causal_additive',rank)
            expected=attention.int8_attention(q,k,v,attn_mask=mask).transpose(1,2).reshape(1,353,-1)
            assert torch.equal(te_attention(block,q,k,v,mask),expected)
            expected=attention.int8_attention(q,k,v).transpose(1,2).reshape(1,353,-1)
            assert torch.equal(dit_attention(block,q,k,v,{}),expected)
            import comfy.quant_ops
            package_fn=ck.int8_attention
            with attention.native_scope():
                assert torch.equal(comfy.quant_ops.ck.int8_attention(q,k,v).transpose(1,2).reshape(1,353,-1),expected)
            assert ck.int8_attention is package_fn
            assert torch.equal(comfy.quant_ops.ck.int8_attention(q,k,v),ck.int8_attention(q,k,v))
            state['controls'].append(dict(kind='TE_DiT_Native_VAE_defaults_and_package_isolation',passed=True))
            lengths=(128,353) if local else (128,353,1306,4096)
            for n in lengths:
                q,k,v=inputs(n,n,128,32,4,rank,821)
                for kind in ('none','causal_additive'):
                    mask=mask_for(n,n,kind,rank)
                    functions=dict(pinned=lambda:ck.int8_attention(q,k,v,attn_mask=mask),
                        corrected_default=lambda:attention.int8_attention(q,k,v,attn_mask=mask))
                    timing=measure(functions,repeats=5 if local else 9)
                    memory={}
                    for name,fn in functions.items():
                        torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();before=torch.cuda.memory_allocated()
                        out=fn();torch.cuda.synchronize()
                        memory[name]=torch.cuda.max_memory_allocated()-before;del out
                    state['timing'].append(dict(n=n,h=32,hk=4,d=128,mask=kind,timing=timing,memory_extra_bytes=memory))
                    save(output,state)
            if not local:
                q,k,v=inputs(16384,16384,64,4,4,rank,821)
                old=ck.int8_attention(q,k,v);new=attention.int8_attention(q,k,v)
                assert torch.equal(new.bfloat16().float(),old)
                state['controls'].append(dict(kind='long_noncausal',n=16384,h=4,hk=4,d=64,rounded_byte_equal=True,
                    timing=measure(dict(pinned=lambda:ck.int8_attention(q,k,v),
                        corrected_default=lambda:attention.int8_attention(q,k,v)),repeats=3,iterations=2)))
            state['status']='completed'
    except BaseException:
        state.update(status='failed',error=traceback.format_exc());raise
    finally:state['seconds']=time.monotonic()-started;save(output,state)


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--rank',type=int);p.add_argument('--local',action='store_true');args=p.parse_args()
    if args.rank is not None:return worker(args.rank,args.output,args.local)
    args.output.mkdir(parents=True,exist_ok=True)
    state=dict(status='running',torch=torch.__version__,cuda=torch.version.cuda,
        packages={name:md.version(name) for name in ('comfy-kitchen','tilelang','numpy')},ranks=[])
    assert state['packages']['comfy-kitchen']=='0.2.37' and state['packages']['tilelang']=='0.1.13'
    try:
        for rank in range(1 if args.local else 2):
            with (args.output/f'rank{rank}.log').open('w') as log:
                command=[sys.executable,'-u','-m','benchmarks.kitchen_attention_default_matrix',
                    '--rank',str(rank),'--output',str(args.output/f'rank{rank}.json')]
                if args.local:command+=['--local']
                result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=360)
            row=json.loads((args.output/f'rank{rank}.json').read_text());state['ranks'].append(row)
            if result.returncode or row['status']!='completed':raise RuntimeError('Kitchen default operator worker failed')
        if not args.local:assert len({r['uuid'] for r in state['ranks']})==2
        state['status']='completed'
    except BaseException:state.update(status='failed',error=traceback.format_exc());raise
    finally:
        for path,key in ((Path('/kaggle/working/light_setup/delivery_binding.json'),'delivery_binding'),
                         (Path(__file__).with_name('kitchen_default_sources.json'),'supplemental_sources')):
            if path.exists():state[key]=json.loads(path.read_text())
        save(args.output/'result.json',state)
        if Path('/kaggle/working').exists():save('/kaggle/working/000_kitchen_default.json',state)


if __name__=='__main__':main()
