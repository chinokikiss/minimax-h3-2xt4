"""Shared causal/noncausal Kitchen precision/default contracts; CPU only."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ComfyUI'))
from patches import kitchen_attention as attention


class KitchenDefault(unittest.TestCase):
    def test_low_precision_and_cpu_delegate_without_build_or_quantization(self):
        for dtype in (torch.float16, torch.bfloat16, torch.float32):
            q = torch.zeros(1,2,3,64,dtype=dtype)
            mask = torch.ones(3,3,dtype=torch.bool)
            with patch.object(attention,'_backend',side_effect=AssertionError('No compiler/cache lookup')), \
                 patch('comfy_kitchen.int8_attention',return_value=q) as old:
                self.assertIs(attention.int8_attention(q,q,q,attn_mask=mask),q)
                old.assert_called_once_with(q,q,q,attn_mask=mask)

    def test_fp32_cuda_uses_same_producer_with_original_mask_and_scale(self):
        q = SimpleNamespace(dtype=torch.float32,is_cuda=True,requires_grad=False,device='cuda:0')
        mask = object(); packed = object(); backend = Mock(); backend.execute.return_value='direct'
        with patch('torch.cuda.get_device_capability',return_value=(7,5)), \
             patch.object(attention,'_backend',return_value=backend) as lookup, \
             patch('comfy_kitchen.prequantize_int8_attention',return_value=packed) as quantize, \
             patch('comfy_kitchen.int8_attention',side_effect=AssertionError('No BF16 path')):
            self.assertEqual(attention.int8_attention(q,q,q,attn_mask=mask,scale=.25),'direct')
            quantize.assert_called_once_with(q,q,q,scale=.25,attn_mask=mask)
            lookup.assert_called_once_with('75');backend.execute.assert_called_once_with(packed)

    def test_grad_contract_stays_with_pinned_api(self):
        q = torch.zeros(1,2,3,64,requires_grad=True)
        with patch.object(attention,'_backend',side_effect=AssertionError('No inference kernel')), \
             patch('comfy_kitchen.int8_attention',return_value=q) as old:
            self.assertIs(attention.int8_attention(q,q,q,scale=.5),q)
            self.assertEqual(old.call_args.kwargs,{'scale':.5,'attn_mask':None})

    def packed(self,n=353,nk=353,d=128,mask=None,ck=64,h=32):
        return SimpleNamespace(q=torch.empty((1,h,n,d),device='meta'),
            k=torch.empty((1,4,nk,d),device='meta'),attn_mask=mask,cta_k=ck)

    def test_unmasked_and_dense_masks_are_distinct_launches(self):
        p=self.packed()
        self.assertEqual(attention.launch_metadata(p,(7,5))[0],0)
        p.attn_mask=torch.empty((1,32,353,353),device='meta',dtype=torch.bool)
        mode,strides,code,bias,cq=attention.launch_metadata(p,(7,5))
        self.assertEqual((mode,code,bias,cq),(1,3,0,128))
        self.assertEqual(strides,p.attn_mask.stride())
        p.attn_mask=torch.empty((1,1,1,353),device='meta').expand(1,32,353,353)
        self.assertEqual(attention.launch_metadata(p,(7,5))[0],2)

    def test_prepared_mask_broadcast_strides_and_pointer_are_preserved(self):
        class Mask:
            ndim=3;shape=(1,2,1164);dtype=torch.float32
            def stride(self,i):return (2328,1164,1)[i]
            def data_ptr(self):return 1024
        p=self.packed(nk=1153,mask=Mask(),ck=128)
        mode,strides,code,bias,cq=attention.launch_metadata(p,(7,5))
        self.assertEqual((mode,strides,code,bias,cq),(3,(0,1164,0,1),0,1024+1280*4,128))
        self.assertEqual(attention.launch_metadata(p,(12,0))[-1],64)

    def test_local_blackwell_shape_policy_matches_pinned_schedule(self):
        p=self.packed(n=4096,nk=4096,ck=128,h=32)
        self.assertEqual(attention.launch_metadata(p,(7,5),36)[-1],128)
        self.assertEqual(attention.launch_metadata(p,(12,0),36)[-1],64)
        p=self.packed(n=4422,nk=4422,ck=128,h=32)
        self.assertEqual(attention.launch_metadata(p,(12,0),40)[-1],128)

    def test_abi_layout_and_frozen_computation(self):
        self.assertEqual(ctypes.sizeof(attention.AttentionArgs),160)
        self.assertEqual(attention.AttentionArgs.stream.offset,152)
        self.assertEqual(attention.AttentionArgs.out_dim.offset,144)
        self.assertEqual(attention.AttentionArgs.scale.offset,148)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'derived.cuh';attention.derive_header(path)
            text=path.read_text();original=(attention.ROOT/'vendor/qk_int_sv_i8_cuda.cuh').read_text()
        text=text.replace('std::is_same<DTypeOut, nv_bfloat16>::value ||\n'
            '                    std::is_same<DTypeOut, float>::value,\n'
            '                "DTypeOut must be half, nv_bfloat16 or float");',
            'std::is_same<DTypeOut, nv_bfloat16>::value,\n'
            '                "DTypeOut must be half or nv_bfloat16");')
        self.assertEqual(text.split('  if constexpr (std::is_same<DTypeOut, float>::value) {')[0],
            original.split('  // save the result to shared memory\n')[0])

    def library(self,folder):
        path=Path(folder)/('kitchen_fp32.dll' if os.name=='nt' else 'kitchen_fp32.so');path.write_bytes(b'fixture')
        path.with_name('build_receipt.json').write_text(json.dumps(dict(status='passed',target='sm_75',
            compiler_version='V12.8.93',sources={'fixture':'source'},artifact_sha256=hashlib.sha256(b'fixture').hexdigest())))
        return path

    def test_cache_reuses_verified_build_and_rejects_corruption(self):
        with tempfile.TemporaryDirectory() as folder, \
             patch.dict(os.environ,{attention.LIBRARY_ENV:'','H3_KITCHEN_FP32_CACHE':folder}), \
             patch.object(attention,'source_hashes',return_value={'fixture':'source'}), \
             patch.object(attention,'build',side_effect=lambda out,**kw:self.library(out)) as build:
            first=attention.prepare();self.assertEqual(first,attention.prepare());self.assertEqual(build.call_count,1)
            first.write_bytes(b'corrupt')
            with self.assertRaisesRegex(RuntimeError,'binary mismatch'):attention.prepare()

    def test_build_timeout_does_not_remove_another_owners_lock(self):
        with tempfile.TemporaryDirectory() as folder, \
             patch.dict(os.environ,{attention.LIBRARY_ENV:'','H3_KITCHEN_FP32_CACHE':folder}), \
             patch.object(attention,'source_hashes',return_value={'fixture':'source'}):
            fingerprint=hashlib.sha256(json.dumps({'fixture':'source'},sort_keys=True).encode()).hexdigest()[:24]
            root=Path(folder)/('75-'+fingerprint);root.mkdir();lock=root/'build.lock';lock.touch()
            with patch.object(attention.time,'monotonic',side_effect=[0,331]):
                with self.assertRaises(TimeoutError):attention.prepare()
            self.assertTrue(lock.exists())

    def test_native_scope_is_nested_thread_local_and_preserves_other_apis(self):
        import comfy.quant_ops
        original=comfy.quant_ops.ck
        kitchen=SimpleNamespace(int8_attention=Mock(return_value='old'),rms_rope_split_half_=object())
        try:
            comfy.quant_ops.ck=kitchen
            with patch.object(attention,'int8_attention',return_value='new'):
                with attention.native_scope():
                    self.assertEqual(comfy.quant_ops.ck.int8_attention(),'new')
                    self.assertIs(comfy.quant_ops.ck.rms_rope_split_half_,kitchen.rms_rope_split_half_)
                    rows=[];thread=threading.Thread(target=lambda:rows.append(comfy.quant_ops.ck.int8_attention()))
                    thread.start();thread.join();self.assertEqual(rows,['old'])
                    with attention.native_scope():self.assertEqual(comfy.quant_ops.ck.int8_attention(),'new')
                    self.assertEqual(comfy.quant_ops.ck.int8_attention(),'new')
                self.assertEqual(comfy.quant_ops.ck.int8_attention(),'old')
                self.assertIs(comfy.quant_ops.ck,kitchen)
        finally:comfy.quant_ops.ck=original


if __name__=='__main__':unittest.main()
